package game;

public enum Colour {
	LIGHT, DARK
}
